﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMA_zadacha
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Dv;
            int P;
            int T;
            int N;
            int A;


        
            P = Convert.ToInt32(Summa_vklada.Text);
            T = Convert.ToInt32(Srok.Text);
            N = Convert.ToInt32(Procent.Text);
            A = (N / 100);
            Dv = ((A * (1 + N / 12)) ^ T);
            Itogo.Text = Convert.ToString(Dv);


        }
    }
}

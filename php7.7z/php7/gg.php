<?php
require_once 'podkl.php';
$link = mysqli_connect($host, $user, $password, $database)
or die("Error". mysqli_error($link));
$query = "SELECT Dolznost FROM dolznosti";
$result = mysqli_query($link, $query) or die("error". mysqli_error($link));
if($result)
{
echo "<th>Выберите должность: </th><select name = 'gg' > ";
	while ($row = mysqli_fetch_row($result)){
	$a = $row[0];
	echo $a;
	echo "<option value='$a-> Dolznost'>$a</option>";
	echo "</br>";
}	
echo "</select>";

mysqli_free_result($result);
}
?>
<form action='raschet.php' method='post'>
<input type='submit' value='Ответить'>
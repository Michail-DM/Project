<?php
require_once 'podkl.php';

$link = mysqli_connect($host, $user, $password, $database)
or die("Error". mysqli_error($link));

$query = "SELECT * FROM service";
$result = mysqli_query($link, $query) or die("error". mysqli_error($link));
if($result)
{
	$rows = mysqli_num_rows($result);
echo "<table><tr><th>Id</th>GG</th><th>Название</th></tr>";
for ($i = 0; $i < $rows ; ++$i)
{
	$row = mysqli_fetch_row($result);
	echo "<tr>";
	for ($j = 0; $j < 3; ++$j) echo "<td>$row[$j]</td>";
	echo "</tr>";
}	
echo "</table>";

mysqli_free_result($result);
}
mysqli_close($link);
?>
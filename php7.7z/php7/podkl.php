<?php
$host = 'localhost';
$database = 'dmitriev';
$user = 'root';
$password = 'root';
?>
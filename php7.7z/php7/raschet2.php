<?PHP
if (isset($_POST['day']))
	
$day = $_POST['day'];
echo "</br>";	
require_once 'podkl.php';

$link = mysqli_connect($host, $user, $password, $database)
or die("Error". mysqli_error($link));

$query = "SELECT dolznosti.Dolznost, dolznosti.ZP FROM dolznosti";
$result = mysqli_query($link, $query) or die("error". mysqli_error($link));
if($result)
{
	while ($row = mysqli_fetch_row($result)){
	$a = $row[0];
	echo  $a;
	$b = $row[1];
	$zrp=$b*$day;
	$fcc=$zrp*2.9/100;
	echo ": Взнос ФСС: ", $fcc, ", ";
	echo "</br>";
	$ffcp=$zrp*1.8/100;
	echo "Фзнос ФСС по травматизму: ", $ffcp, ", ";
	echo "</br>";
	$itog= $zrp-$fcc-$ffcp;
	echo " Итоговая ЗП: ", $itog, " руб.";
	echo "</br>";
}	
echo "</ul>";

mysqli_free_result($result);
}
mysqli_close($link);



?>
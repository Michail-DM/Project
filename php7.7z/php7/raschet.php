<?PHP
require_once 'podkl.php';
$link = mysqli_connect($host, $user, $password, $database)
or die("Error". mysqli_error($link));
$query = "SELECT Dolznost, ZP FROM dolznosti";
$result = mysqli_query($link, $query) or die("error". mysqli_error($link));
if($result)
{
	while ($row = mysqli_fetch_row($result)) {
    echo "<tr>";
        for ($j = 0 ; $j < 3 ; ++$j) echo "<td>$row[$j]</td>";
		$n= $row[$j];
    echo "</tr>";

}	
echo "</select>";

mysqli_free_result($result);
}


if (isset($_POST['day'], $_POST['gg']))
$day = $_POST['day'];
$sel = $_POST['gg'];

if (isset($_POST['day']))
	
$day = $_POST['day'];
echo "den", $day;
echo "</br>";
if ($day>0){
	$zrp=$j*$day;
	$fcc=$zrp*2.8/100;
	$ffcp=$zrp*1.8/100;
	$itog= $zrp-$fcc-$fccp;
	echo '<td> Размер ЗП', $itog, 'p.<td>';
	}
	else echo 'Недостаточно данных';
?>
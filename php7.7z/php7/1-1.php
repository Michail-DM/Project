<?php
require_once 'podkl.php';

$link = mysqli_connect($host, $user, $password, $database)
or die("Error". mysqli_error($link));

$query = "SELECT dolznosti.Dolznost, dolznosti.ZP FROM dolznosti";
$result = mysqli_query($link, $query) or die("error". mysqli_error($link));
if($result)
{
	while ($row = mysqli_fetch_row($result)){
	$a = $row[0];
	echo $a, " " ;
	$b = $row[1];
	echo $b, " руб день";
	echo "</br>";
}	
echo "</ul>";

mysqli_free_result($result);
}
mysqli_close($link);
?>
<form action="raschet2.php" method="POST">
Отраб. дни: <input type="text" name="day" /><br><br>
<input type="submit" value="Ответить">
<br><br>
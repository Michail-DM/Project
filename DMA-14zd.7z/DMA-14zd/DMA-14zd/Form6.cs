﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMA_14zd
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a;
            a = Convert.ToInt32(Vysota.Text);
            if (comboBox1.SelectedIndex == 0)
            {
                a = (a * 100);
                Shirina.Text = Convert.ToString(a);
            }
            if (comboBox1.SelectedIndex == 1)
            {
                a = (a * 250);
                Shirina.Text = Convert.ToString(a);
            }
            if (comboBox1.SelectedIndex == 2)
            {
                a = (a * 404);
                Shirina.Text = Convert.ToString(a);
                
                if (radiofiksator.Checked)
                {
                    a = (a + 100);
                    Oplata.Text = Convert.ToString(a);
                }
                else
               if (radioclassik.Checked)
                {
                    a = (a  + 200);
                    Oplata.Text = Convert.ToString(a);
                }
                else
               if (radiogruz.Checked)
                {
                    a = (a + 500);
                    Oplata.Text = Convert.ToString(a);
                }
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
    }
}

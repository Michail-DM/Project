﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMA_14zd
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a;
            a = Convert.ToInt32(Etash.Text);
            if (radionet.Checked)
            {
                a = (a * 30);
                Oplata.Text = Convert.ToString(a);
            }
            else
                if (radioclassik.Checked)
            {
                a = (a * 30 + 200);
                Oplata.Text = Convert.ToString(a);
            }
            else
                if (radiogruz.Checked)
            {
                a = (a * 30 + 500);
                Oplata.Text = Convert.ToString(a);
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}

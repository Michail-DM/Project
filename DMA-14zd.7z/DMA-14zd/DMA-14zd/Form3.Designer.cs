﻿
namespace DMA_14zd
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radiotaxi = new System.Windows.Forms.RadioButton();
            this.radiovan = new System.Windows.Forms.RadioButton();
            this.radiobus = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.Time = new System.Windows.Forms.TextBox();
            this.Oplata = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // radiotaxi
            // 
            this.radiotaxi.AutoSize = true;
            this.radiotaxi.Location = new System.Drawing.Point(118, 78);
            this.radiotaxi.Name = "radiotaxi";
            this.radiotaxi.Size = new System.Drawing.Size(45, 17);
            this.radiotaxi.TabIndex = 0;
            this.radiotaxi.TabStop = true;
            this.radiotaxi.Text = "Taxi";
            this.radiotaxi.UseVisualStyleBackColor = true;
            // 
            // radiovan
            // 
            this.radiovan.AutoSize = true;
            this.radiovan.Location = new System.Drawing.Point(118, 118);
            this.radiovan.Name = "radiovan";
            this.radiovan.Size = new System.Drawing.Size(69, 17);
            this.radiovan.TabIndex = 1;
            this.radiovan.TabStop = true;
            this.radiovan.Text = "Microvan";
            this.radiovan.UseVisualStyleBackColor = true;
            // 
            // radiobus
            // 
            this.radiobus.AutoSize = true;
            this.radiobus.Location = new System.Drawing.Point(118, 162);
            this.radiobus.Name = "radiobus";
            this.radiobus.Size = new System.Drawing.Size(43, 17);
            this.radiobus.TabIndex = 2;
            this.radiobus.TabStop = true;
            this.radiobus.Text = "Bus";
            this.radiobus.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(115, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Часы";
            // 
            // Time
            // 
            this.Time.Location = new System.Drawing.Point(250, 220);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(100, 20);
            this.Time.TabIndex = 4;
            // 
            // Oplata
            // 
            this.Oplata.Location = new System.Drawing.Point(250, 360);
            this.Oplata.Name = "Oplata";
            this.Oplata.Size = new System.Drawing.Size(100, 20);
            this.Oplata.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Оплата";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(237, 288);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Рассчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Oplata);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radiobus);
            this.Controls.Add(this.radiovan);
            this.Controls.Add(this.radiotaxi);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radiotaxi;
        private System.Windows.Forms.RadioButton radiovan;
        private System.Windows.Forms.RadioButton radiobus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Time;
        private System.Windows.Forms.TextBox Oplata;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}
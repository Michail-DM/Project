﻿
namespace DMA_14zd
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radio9Х12 = new System.Windows.Forms.RadioButton();
            this.radio12Х15 = new System.Windows.Forms.RadioButton();
            this.radio18Х24 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Oplata = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Kolichestvo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // radio9Х12
            // 
            this.radio9Х12.AutoSize = true;
            this.radio9Х12.Location = new System.Drawing.Point(151, 124);
            this.radio9Х12.Name = "radio9Х12";
            this.radio9Х12.Size = new System.Drawing.Size(50, 17);
            this.radio9Х12.TabIndex = 0;
            this.radio9Х12.TabStop = true;
            this.radio9Х12.Text = "9Х12";
            this.radio9Х12.UseVisualStyleBackColor = true;
            // 
            // radio12Х15
            // 
            this.radio12Х15.AutoSize = true;
            this.radio12Х15.Location = new System.Drawing.Point(151, 158);
            this.radio12Х15.Name = "radio12Х15";
            this.radio12Х15.Size = new System.Drawing.Size(56, 17);
            this.radio12Х15.TabIndex = 1;
            this.radio12Х15.TabStop = true;
            this.radio12Х15.Text = "12Х15";
            this.radio12Х15.UseVisualStyleBackColor = true;
            // 
            // radio18Х24
            // 
            this.radio18Х24.AutoSize = true;
            this.radio18Х24.Location = new System.Drawing.Point(151, 194);
            this.radio18Х24.Name = "radio18Х24";
            this.radio18Х24.Size = new System.Drawing.Size(56, 17);
            this.radio18Х24.TabIndex = 2;
            this.radio18Х24.TabStop = true;
            this.radio18Х24.Text = "18Х24";
            this.radio18Х24.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(330, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "К оплате";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(175, 404);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Рассчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Oplata
            // 
            this.Oplata.Location = new System.Drawing.Point(408, 66);
            this.Oplata.Name = "Oplata";
            this.Oplata.Size = new System.Drawing.Size(100, 20);
            this.Oplata.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(106, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Количество";
            // 
            // Kolichestvo
            // 
            this.Kolichestvo.Location = new System.Drawing.Point(190, 268);
            this.Kolichestvo.Name = "Kolichestvo";
            this.Kolichestvo.Size = new System.Drawing.Size(100, 20);
            this.Kolichestvo.TabIndex = 7;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Kolichestvo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Oplata);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radio18Х24);
            this.Controls.Add(this.radio12Х15);
            this.Controls.Add(this.radio9Х12);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radio9Х12;
        private System.Windows.Forms.RadioButton radio12Х15;
        private System.Windows.Forms.RadioButton radio18Х24;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Oplata;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Kolichestvo;
    }
}
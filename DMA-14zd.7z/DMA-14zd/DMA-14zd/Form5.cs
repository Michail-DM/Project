﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMA_14zd
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a;
            a = Convert.ToInt32(textBox1.Text);
            if (comboBox1.SelectedIndex == 0)
            {
                a = (a * 100);
                textBox2.Text = Convert.ToString(a);
            }
            if (comboBox1.SelectedIndex == 1)
            {
                a = (a * 250);
                textBox2.Text = Convert.ToString(a);
            }
            if (comboBox1.SelectedIndex == 2)
            {
                a = (a * 404);
                textBox2.Text = Convert.ToString(a);
            }
        }
    }
}

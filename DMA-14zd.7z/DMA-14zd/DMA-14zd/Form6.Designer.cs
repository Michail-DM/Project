﻿
namespace DMA_14zd
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Vysota = new System.Windows.Forms.TextBox();
            this.Shirina = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.radiofiksator = new System.Windows.Forms.RadioButton();
            this.radioproventr = new System.Windows.Forms.RadioButton();
            this.radiosetka = new System.Windows.Forms.RadioButton();
            this.Oplata = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Vysota
            // 
            this.Vysota.Location = new System.Drawing.Point(69, 72);
            this.Vysota.Name = "Vysota";
            this.Vysota.Size = new System.Drawing.Size(100, 20);
            this.Vysota.TabIndex = 0;
            // 
            // Shirina
            // 
            this.Shirina.Location = new System.Drawing.Point(366, 72);
            this.Shirina.Name = "Shirina";
            this.Shirina.Size = new System.Drawing.Size(100, 20);
            this.Shirina.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Высота и ширина в мм";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Тип механизма открывания";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(69, 151);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Доп опции";
            // 
            // radiofiksator
            // 
            this.radiofiksator.AutoSize = true;
            this.radiofiksator.Location = new System.Drawing.Point(69, 248);
            this.radiofiksator.Name = "radiofiksator";
            this.radiofiksator.Size = new System.Drawing.Size(77, 17);
            this.radiofiksator.TabIndex = 6;
            this.radiofiksator.TabStop = true;
            this.radiofiksator.Text = "Фиксатор";
            this.radiofiksator.UseVisualStyleBackColor = true;
            // 
            // radioproventr
            // 
            this.radioproventr.AutoSize = true;
            this.radioproventr.Location = new System.Drawing.Point(69, 271);
            this.radioproventr.Name = "radioproventr";
            this.radioproventr.Size = new System.Drawing.Size(135, 17);
            this.radioproventr.TabIndex = 7;
            this.radioproventr.TabStop = true;
            this.radioproventr.Text = "Микропроветривание";
            this.radioproventr.UseVisualStyleBackColor = true;
            // 
            // radiosetka
            // 
            this.radiosetka.AutoSize = true;
            this.radiosetka.Location = new System.Drawing.Point(69, 294);
            this.radiosetka.Name = "radiosetka";
            this.radiosetka.Size = new System.Drawing.Size(113, 17);
            this.radiosetka.TabIndex = 8;
            this.radiosetka.TabStop = true;
            this.radiosetka.Text = "Маскитная сетка";
            this.radiosetka.UseVisualStyleBackColor = true;
            // 
            // Oplata
            // 
            this.Oplata.Location = new System.Drawing.Point(69, 428);
            this.Oplata.Name = "Oplata";
            this.Oplata.Size = new System.Drawing.Size(100, 20);
            this.Oplata.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(69, 401);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Сумма к оплате";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(497, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Рассчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Oplata);
            this.Controls.Add(this.radiosetka);
            this.Controls.Add(this.radioproventr);
            this.Controls.Add(this.radiofiksator);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Shirina);
            this.Controls.Add(this.Vysota);
            this.Name = "Form6";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Vysota;
        private System.Windows.Forms.TextBox Shirina;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radiofiksator;
        private System.Windows.Forms.RadioButton radioproventr;
        private System.Windows.Forms.RadioButton radiosetka;
        private System.Windows.Forms.TextBox Oplata;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
    }
}
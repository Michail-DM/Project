﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMA_14zd
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a;
            a = Convert.ToInt32(Time.Text);
            if (radiotaxi.Checked)
            {
                a = (a * 200);
                Oplata.Text = Convert.ToString(a);
            }
            else
                if (radiovan.Checked)
            {
                a = (a * 800);
                Oplata.Text = Convert.ToString(a);
            }
            else
                if (radiobus.Checked)
            {
                a = (a * 1800);
                Oplata.Text = Convert.ToString(a);
            }
        }
    }
}

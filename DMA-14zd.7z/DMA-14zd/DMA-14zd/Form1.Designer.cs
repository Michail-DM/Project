﻿
namespace DMA_14zd
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Rasstoyanie = new System.Windows.Forms.TextBox();
            this.Radio_Gryzchik = new System.Windows.Forms.RadioButton();
            this.Radio_nogryzchik = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Oplata = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 265);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Рассчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Расстояние";
            // 
            // Rasstoyanie
            // 
            this.Rasstoyanie.Location = new System.Drawing.Point(315, 58);
            this.Rasstoyanie.Name = "Rasstoyanie";
            this.Rasstoyanie.Size = new System.Drawing.Size(100, 20);
            this.Rasstoyanie.TabIndex = 2;
            // 
            // Radio_Gryzchik
            // 
            this.Radio_Gryzchik.AutoSize = true;
            this.Radio_Gryzchik.Location = new System.Drawing.Point(160, 132);
            this.Radio_Gryzchik.Name = "Radio_Gryzchik";
            this.Radio_Gryzchik.Size = new System.Drawing.Size(88, 17);
            this.Radio_Gryzchik.TabIndex = 3;
            this.Radio_Gryzchik.TabStop = true;
            this.Radio_Gryzchik.Text = "С грузчиком";
            this.Radio_Gryzchik.UseVisualStyleBackColor = true;
            // 
            // Radio_nogryzchik
            // 
            this.Radio_nogryzchik.AutoSize = true;
            this.Radio_nogryzchik.Location = new System.Drawing.Point(160, 155);
            this.Radio_nogryzchik.Name = "Radio_nogryzchik";
            this.Radio_nogryzchik.Size = new System.Drawing.Size(92, 17);
            this.Radio_nogryzchik.TabIndex = 4;
            this.Radio_nogryzchik.TabStop = true;
            this.Radio_nogryzchik.Text = "Без грузчика";
            this.Radio_nogryzchik.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(143, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Оплата руб.";
            // 
            // Oplata
            // 
            this.Oplata.Location = new System.Drawing.Point(315, 336);
            this.Oplata.Name = "Oplata";
            this.Oplata.Size = new System.Drawing.Size(100, 20);
            this.Oplata.TabIndex = 6;
            
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Oplata);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Radio_nogryzchik);
            this.Controls.Add(this.Radio_Gryzchik);
            this.Controls.Add(this.Rasstoyanie);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Rasstoyanie;
        private System.Windows.Forms.RadioButton Radio_Gryzchik;
        private System.Windows.Forms.RadioButton Radio_nogryzchik;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Oplata;
    }
}


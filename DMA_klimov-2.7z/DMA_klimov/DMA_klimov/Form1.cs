﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMA_klimov
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            RichTextBoxEx rboxex = new RichTextBoxEx();
            rboxex.Parent = this;
            rboxex.Top = 400;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = richTextBox1.Rtf;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Устанавливаем фокус на richTextBox
            richTextBox1.Focus();
            // Устанавливаем цвет для выделенного текста
            richTextBox1.SelectionColor = Color.Red;
            // Устанавливаем шрифт
            richTextBox1.SelectionFont = new Font("Courier", 10, FontStyle.Bold);

        }

        private void richTextBox1_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.LinkText);
        }
        [DllImport("User32.dll")]
        static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        const int GWL_STYLE = -16;
        const int WS_HSCROLL = 0x00100000;
        const int WS_VSCROLL = 0x00200000;
        // Проверка на наличие вертикальной прокрутки
        bool IsVertScrollPresent(Control control)
        {
            int style = GetWindowLong(control.Handle, GWL_STYLE);
            return (style & WS_VSCROLL) > 0;
        }
        // Проверка на наличие горизонтальной прокрутки
        bool IsHorScrollPresent(Control control)
        {
            int style = GetWindowLong(control.Handle, GWL_STYLE);
            return (style & WS_HSCROLL) > 0;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Вертикальная прокрутка: " +
 IsVertScrollPresent(richTextBox1).ToString() +
 Environment.NewLine + "Горизонтальная прокрутка: " +
 IsHorScrollPresent(richTextBox1).ToString();
        }
        class RichTextBoxEx : RichTextBox
        {
            protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
            {
                //Проверяем на нажатие Shift+Insert и Ctrl+V
                if ((keyData & (Keys.Shift | Keys.Insert)) ==
                (Keys.Shift | Keys.Insert)
                || ((keyData & (Keys.Control | Keys.V)) ==
                (Keys.Control | Keys.V)))
                    return true;
                return base.ProcessCmdKey(ref msg, keyData);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_KeyPress(object sender, KeyPressEventArgs e)
        {
            dateTimePicker1.CustomFormat = " ";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            // Устанавливаем фокус
            dateTimePicker1.Focus();
            // Посылаем команду
            SendKeys.Send("{F4}");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.BackColor = Color.FromArgb(60, 255, 192, 192);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://rusproject.narod.ru/");
        }

        private Icon[] aIcons = new Icon[2];
        // текущий значок
        int curIcon = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            linkLabel2.Text = "Yandex Google Rambler GoGo";
            linkLabel2.LinkBehavior = LinkBehavior.HoverUnderline;
     
            linkLabel2.LinkClicked +=
            new LinkLabelLinkClickedEventHandler(linkLabel2_LinkClicked);
            aIcons[0] = new Icon("134187_taxi_car_icon.ico");
            aIcons[1] = new Icon("2639905_car_icon.ico");

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LinkLabel lnk = new LinkLabel();
            lnk = (LinkLabel)sender;
            lnk.Links[lnk.Links.IndexOf(e.Link)].Visited = true;
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            notifyIcon1.Icon = aIcons[curIcon];
            curIcon++;
            if (curIcon > 3) curIcon = 0;
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            this.timer1.Stop();
            notifyIcon1.Visible = true;
            MessageBox.Show("Мигание приостановлено");
        }
        private bool m_CloseOK = false;
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Пользователь выходит из программы не через контекстное меню
            if (m_CloseOK == false)
            {
                e.Cancel = true;
                this.Hide();
            }

        }

        private void ttToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // выходим из программы по-настоящему
            m_CloseOK = true;
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.listView1.SelectedItems.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Установим фокус
            listView1.Focus();
            // Выбираем второй элемент
            listView1.Items[1].Selected = true;
        }
    }
}
